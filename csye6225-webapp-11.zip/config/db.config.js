module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "parasites",
    DATABASE: "csye6225"
  };