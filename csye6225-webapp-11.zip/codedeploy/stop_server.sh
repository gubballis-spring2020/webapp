#!/bin/bash

#pm2 stop app.js
pwd
cd ..
pwd
cd ..
pwd
sudo rm -rf ccwebapps/